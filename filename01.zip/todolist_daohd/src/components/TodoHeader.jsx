import { useEffect, useState } from "react";
import "./Todo.css";
import { Link } from "react-router-dom";
const TodoList = () => {
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem("tasks");
    if (savedTasks) {
      return JSON.parse(savedTasks);
    } else {
      return [];
    }
  });
  const handleDel = (id) => {
    const removeItem = tasks.filter((task) => {
      return task.id !== id;
    });
    setTasks(removeItem);
  };
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  return (
    <div>
      <table>
        <tr>
          <th>Name</th>
          <th>Active</th>
          <th>Priority</th>
          <th>Action</th>
        </tr>
        {tasks.map((task) => (
          <tr key={task.id}>
            <th>{task.name}</th>
            <th>{task.status}</th>
            <th>{task.priority}</th>
            <th>
              <button onClick={() => handleDel(task.id)}>
                <i className="fa-solid fa-trash"></i>
              </button>
              <Link to={`/todolist/edit?id=${task.id}`}>
                <button>
                  <i className="fa-solid fa-pen-to-square"></i>
                </button>
              </Link>
            </th>
          </tr>
        ))}
      </table>
    </div>
  );
};
export default TodoList;
