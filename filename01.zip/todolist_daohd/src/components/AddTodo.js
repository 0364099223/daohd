import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { DONE, OPEN, PROGRESS, MEDIUM, HIGH, LOW } from "./constants";
const AddTodo = () => {
  let navigate = useNavigate();
  const [name, setName] = useState("");
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem("tasks");
    if (savedTasks) {
      return JSON.parse(savedTasks);
    } else {
      return [];
    }
  });
  const [status, setStatus] = useState(OPEN);
  const [priority, setPriority] = useState(LOW);
  const subMitCreate = () => {
    console.log(tasks, "daohd");
    console.log(name + status + priority, "daohd002");
    if (name && tasks.length !== 0) {
      setTasks([
        ...tasks,
        {
          id: tasks[tasks.length - 1].id + 1,
          name: name,
          status: status,
          priority: priority,
        },
      ]);
    } else if (name && tasks.length === 0) {
      setTasks([
        {
          id: 1,
          name: name,
          status: status,
          priority: priority,
        },
      ]);
    }
    localStorage.setItem("tasks", JSON.stringify(tasks));
  };
  const handleOutform = () => {
    navigate("/");
  };
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);
  useEffect(() => {
    setTasks(JSON.parse(localStorage.getItem("tasks")));
  }, []);
  return (
    <form className="contant_create" onSubmit={handleOutform}>
      <div className="contant_input">
        <input
          className="input_name"
          type="text"
          name="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className="contant_select">
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          name="priority"
        >
          <option value={OPEN}>open</option>
          <option value={DONE}>done</option>
          <option value={PROGRESS}>in progress</option>
        </select>
      </div>
      <div>
        <select
          value={priority}
          name="priority"
          className="contant_select"
          onChange={(e) => setPriority(e.target.value)}
        >
          <option value={MEDIUM}>MEDIUM</option>
          <option value={HIGH}>HIGH</option>
          <option value={LOW}>LOW</option>
        </select>
      </div>

      <button type="submit" className="btn-Save" onClick={subMitCreate}>
        <i className="fa-solid fa-check"></i>Save
      </button>

      <Link to="/">
        <button type="">
          <i className="fa-solid fa-x"></i>Cancel
        </button>
      </Link>
    </form>
  );
};
export default AddTodo;
