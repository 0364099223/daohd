import { useEffect, useState } from "react";
import { DONE, OPEN, PROGRESS, MEDIUM, HIGH, LOW } from "./constants";
import { Link, useSearchParams } from "react-router-dom";

const EditTodo = () => {
  const [name, setName] = useState("");
  let [searchParams] = useSearchParams();
  const id = searchParams.get["id"];

  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem("tasks");
    if (savedTasks) {
      return JSON.parse(savedTasks);
    } else {
      return [];
    }
  });

  const [status, setStatus] = useState(OPEN);
  const [priority, setPriority] = useState(LOW);
  const [currentTask, setCurrentTask] = useState({});

  // const id = window.location.pathname.split("/")[3];
  useEffect(() => {
    setTasks(JSON.parse(localStorage.getItem("tasks")));
  }, []);
  useEffect(() => {
    for (const task of tasks) {
      if (task.id === id) {
        setCurrentTask(task);
        break;
      }
    }
  }, []);

  return (
    <form className="contant_create">
      {console.log("id: ", id)}
      <div className="contant_input">
        <input
          className="input_name"
          type="text"
          name="name"
          value={currentTask.name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className="contant_select">
        <select
          value={currentTask.status}
          onChange={(e) => setStatus(e.target.value)}
          name="priority"
        >
          <option value={OPEN}>open</option>
          <option value={DONE}>done</option>
          <option value={PROGRESS}>in progress</option>
        </select>
      </div>
      <div>
        <select
          value={currentTask.priority}
          name="priority"
          className="contant_select"
          onChange={(e) => setPriority(e.target.value)}
        >
          <option value={MEDIUM}>MEDIUM</option>
          <option value={HIGH}>HIGH</option>
          <option value={LOW}>LOW</option>
        </select>
      </div>
      <button type="submit">
        <i className="fa-solid fa-check"></i>Save
      </button>
      <Link to="/">
        <button type="">
          <i className="fa-solid fa-x"></i>Cancel
        </button>
      </Link>
    </form>
  );
};
export default EditTodo;
