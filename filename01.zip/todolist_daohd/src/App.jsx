import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Edit from "./Pages/Edit";
import Home from "./Pages/Home";
import Create from "./Pages/Create";
import Layout from "./Pages/Component/Layout";
import TodoList from "./components/TodoHeader";
import AddTodo from "./components/AddTodo";
function App() {
  return (
    <div className="contant_header">
      <h2>TODOLIST_DAOHD</h2>
      <div>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="create" element={<Create />} />
              <Route exact path={"/todolist/edit?id=:id"} element={<Edit />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
