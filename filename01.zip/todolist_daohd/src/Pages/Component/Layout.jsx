import { Outlet, Link } from "react-router-dom";
import "./Layout.css";
const Layout = () => {
  return (
    <>
      <div>
        <div>
          <a>
            <Link to="/">Home</Link>
          </a>
          <a>
            <Link to="/create">Create</Link>
          </a>
          {/* <a>
            <Link to="/todolist/edit/${task.id}"></Link>
          </a> */}
        </div>
      </div>

      <Outlet />
    </>
  );
};

export default Layout;
