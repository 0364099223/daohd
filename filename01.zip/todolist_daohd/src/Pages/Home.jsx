import TodoList from "../components/TodoHeader";
const Home = (newTask) => {
  return (
    <div>
      <TodoList />
    </div>
  );
};

export default Home;
