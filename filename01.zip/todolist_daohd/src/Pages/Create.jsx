import AddTodo from "../components/AddTodo";
const Create = () => {
  return (
    <div>
      <AddTodo />
    </div>
  );
};
export default Create;
