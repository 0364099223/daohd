import EditTodo from "../components/EditTodo";

const Edit = () => {
  return (
    <div>
      <EditTodo />
    </div>
  );
};
export default Edit;
