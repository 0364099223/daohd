import "./Todo.css";
import EditTodo from "./EditTodo";
import React, { useEffect, useState } from "react";
// import Addtodo from "./AddTodo";
const Todos = () => {
  const [status, setStatus] = useState(false);
  const [name, setName] = useState("");
  const [inactive, setInactive] = useState(true);
  const [priority, setPriority] = useState("High");
  const [statusEdit, setStatusEdit] = useState(false);
  const [editTask, setEditTask] = useState({});
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem("tasks");
    if (savedTasks) {
      return JSON.parse(savedTasks);
    } else {
      return [];
    }
  });
  const hangdleShowFormAdd = () => {
    setStatus(!status);
    console.log(status, "daohd");
  };
  const handleEditClick = (task) => {
    setStatusEdit(!statusEdit);
    setEditTask(...task);
    setStatus(false);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    console.log(name + inactive + priority, "daohd01");
    if (name) {
      setTasks([
        ...tasks,
        {
          id: tasks[tasks.length - 1].id + 1,
          name: name,
          inactive: inactive,
          priority: priority,
        },
      ]);
    } else {
      setTasks([...tasks]);
    }
    setStatus(false);
    setName("");
    setInactive(true);
    setPriority("High");
  };
  const CanCelAdd = () => {
    setStatus(false);
    setName("");
    setInactive(true);
    setPriority("High");
  };

  const handleDel = (id) => {
    const removeItem = tasks.filter((task) => {
      return task.id !== id;
    });
    setTasks(removeItem);
  };

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);
  return (
    <div className="todo-container">
      <div className="header">TODO - ITEMS</div>
      <div>
        {status || statusEdit ? (
          ""
        ) : (
          <button
            type="button"
            className="btn-addtodo"
            onClick={hangdleShowFormAdd}
          >
            <i class="fa-solid fa-plus"></i>
            Add todo
          </button>
        )}
        {status ? (
          <div className="add-content">
            <div>Add Task</div>
            <input
              type="text"
              placeholder="Add name"
              className="input-name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <div className="select-content">
              <select
                className="sl-status"
                name="inactive"
                value={inactive}
                onChange={(e) => setInactive(e.target.value)}
              >
                <option value={true}>Active</option>
                <option value={false}>Inactive</option>
              </select>
              <select
                className="sl-priority"
                name="priotity"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="High">High</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
              </select>
            </div>
            <button
              type="button"
              className="btn-save"
              onClick={onSubmit}
              disabled={!name}
            >
              Save
            </button>
            <button type="button" className="btn-cancel" onClick={CanCelAdd}>
              Cancel
            </button>
          </div>
        ) : (
          ""
        )}
        {statusEdit ? (
          <EditTodo
            editTask={editTask}
            setEditTask={setEditTask}
            setStatusEdit={setStatusEdit}
          />
        ) : (
          ""
        )}
      </div>
      <div className="tasks">
        <div className="task-name">
          <table>
            <tr>
              <th>Name</th>
              <th>Active</th>
              <th>Priority</th>
              <th>Action</th>
            </tr>
          </table>
        </div>
        {tasks.map((task) => (
          <div className="task-name" key={task.id}>
            <li>{task.name}</li>
            <li
              className={task.inactive === true ? "li-inactive" : "li-active"}
            >
              {task.inactive === true ? "Active" : "inActive"}
            </li>
            <li>{task.priority}</li>
            <li>
              <button
                className="btn-edit"
                onClick={() => handleEditClick(task)}
              >
                Edit
              </button>
              <button className="btn-del" onClick={() => handleDel(task.id)}>
                Del
              </button>
            </li>
          </div>
        ))}
      </div>
    </div>
  );
};
export default Todos;
