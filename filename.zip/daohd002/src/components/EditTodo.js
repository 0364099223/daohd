import React from "react";

const EditTodo = ({ editTask, setEditTask, setStatusEdit }) => {
  const handleChangeTask = () => {};
  return (
    <div className="add-content">
      <div>Edit Task</div>
      <input
        type="text"
        placeholder="Edit name"
        className="input-name"
        name="editName"
      />
      <div className="select-content">
        <select className="sl-status" name="editInactive">
          <option value={true}>Active</option>
          <option value={false}>Inactive</option>
        </select>
        <select className="sl-priority" name="priotity">
          <option value="High">High</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
        </select>
      </div>
      <button type="button" className="btn-save">
        Save
      </button>
      <button
        type="button"
        onClick={(e) => setStatusEdit(false)}
        className="btn-cancel"
      >
        Cancel
      </button>
    </div>
  );
};
export default EditTodo;
