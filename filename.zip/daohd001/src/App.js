import "./App.css";
import Todos from "./components/TodoHeader";
function App() {
  return (
    <div className="App">
      <Todos />
    </div>
  );
}

export default App;
