import React, { useState } from "react";
import "./AddTodo.css";
const Addtodo = () => {
  const [value, setValue] = useState();
  const handleSubmit = () => {};
  return (
    <div className="add-content">
      <input
        type="text"
        placeholder="Add name"
        className="input-name"
        name="name"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <div className="select-content">
        <select className="sl-status">
          <option value={true}>Active</option>
          <option value={false}>Inactive</option>
        </select>
        <select className="sl-priority">
          <option value="High">High</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
        </select>
      </div>
      <button type="button" onClick={handleSubmit} className="btn-save">
        Add
      </button>
    </div>
  );
};
export default Addtodo;
