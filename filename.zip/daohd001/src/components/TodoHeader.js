import "./Todo.css";
import React, { useEffect, useState } from "react";
import Addtodo from "./AddTodo";
function Task({ task }) {
  return (
    <div className="task-name">
      <table>
        <tr key={task.id}>
          <th>{task.Name}</th>
          <th className={task.Inactive ? "th-active" : "th-inactive"}>
            {task.Inactive ? "Active" : "Inactive"}
          </th>
          <th>{task.Priority}</th>
          <th>
            <button className="btn-edit" type="button">
              Edit
            </button>
            <button type="button" className="btn-del">
              Del
            </button>
          </th>
        </tr>
      </table>
    </div>
  );
}
const Todos = () => {
  const [status, setStatus] = useState(false);
  const [tasks, setTasks] = useState([
    {
      id: 1,
      Name: "ES6",
      Inactive: false,
      Priority: "High",
    },
    {
      id: 2,
      Name: "ES5",
      Inactive: true,
      Priority: "Medium",
    },
    {
      id: 3,
      Name: "Daohd",
      Inactive: true,
      Priority: "Low",
    },
  ]);
  const hangdleShowFormAdd = () => {
    setStatus(!status);
    console.log(status, "daohd");
  };
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);
  return (
    <div className="todo-container">
      <div className="header">TODO - ITEMS</div>
      <div>
        <button
          type="button"
          className="btn-addtodo"
          onClick={hangdleShowFormAdd}
        >
          Add todo
        </button>
        {status ? <Addtodo setStatus={setStatus} status={status} /> : ""}
      </div>
      <div className="tasks">
        <div className="task-name">
          <table>
            <tr>
              <th>Name</th>
              <th>Active</th>
              <th>Priority</th>
              <th>Action</th>
            </tr>
          </table>
        </div>
        {tasks.map((task) => (
          <Task task={task} key={task.id} />
        ))}
      </div>
    </div>
  );
};
export default Todos;
